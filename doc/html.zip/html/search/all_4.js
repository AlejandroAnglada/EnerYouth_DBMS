var searchData=
[
  ['is_5fconnected_0',['is_connected',['../classConexionADB.html#a90d4124634181a28ecd00a2eb8339050',1,'ConexionADB']]]
];
