var searchData=
[
  ['dbc_0',['dbc',['../classConexionADB.html#a6573d60ae97714ad1a40aef7145a0910',1,'ConexionADB']]],
  ['disconnect_1',['disconnect',['../classConexionADB.html#aec38caa15109a9cd30240a8a404555a1',1,'ConexionADB']]]
];
