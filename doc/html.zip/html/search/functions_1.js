var searchData=
[
  ['disconnect_0',['disconnect',['../classConexionADB.html#aec38caa15109a9cd30240a8a404555a1',1,'ConexionADB']]]
];
