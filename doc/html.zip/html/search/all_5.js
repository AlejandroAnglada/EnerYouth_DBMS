var searchData=
[
  ['_7econexionadb_0',['~ConexionADB',['../classConexionADB.html#abdbecfd590a5de40202a53f672c56edf',1,'ConexionADB']]]
];
