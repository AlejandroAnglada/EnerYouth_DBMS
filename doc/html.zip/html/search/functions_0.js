var searchData=
[
  ['conexionadb_0',['ConexionADB',['../classConexionADB.html#a0c5d84a6cf55b10efd5bc8b65fbcc3f9',1,'ConexionADB']]],
  ['connect_1',['connect',['../classConexionADB.html#ac0a4921d341548c8ab9de76ee2ea2992',1,'ConexionADB']]]
];
