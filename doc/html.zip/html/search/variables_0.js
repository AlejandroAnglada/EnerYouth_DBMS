var searchData=
[
  ['conexion_5festablecida_0',['conexion_establecida',['../classConexionADB.html#a8f2b5bd62d1d7c5e6063ef9e0e04a418',1,'ConexionADB']]]
];
