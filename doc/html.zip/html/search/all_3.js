var searchData=
[
  ['getconnection_0',['getConnection',['../classConexionADB.html#a6e4d517f454ee1a028da4e323274de57',1,'ConexionADB']]]
];
